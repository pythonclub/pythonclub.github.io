from django.contrib import admin
from core.models import comentario

admin.site.register(comentario)